# --coding:utf-8--
#
# Copyright (c) 2020 vesoft inc. All rights reserved.
#
# This source code is licensed under Apache 2.0 License,
# attached with Common Clause Condition 1.0, found in the LICENSES directory.

import json
import logging
import os
import time

import pytest
from filelock import FileLock
from nebula2.Config import Config
from nebula2.gclient.net import ConnectionPool

from tests.common.configs import all_configs
from tests.common.nebula_service import NebulaService
from tests.common.types import SpaceDesc
from tests.common.utils import load_csv_data

tests_collected = set()
tests_executed = set()
data_dir = os.getenv('NEBULA_DATA_DIR')

CURR_PATH = os.path.dirname(os.path.abspath(__file__))


# pytest hook to handle test collection when xdist is used (parallel tests)
# https://github.com/pytest-dev/pytest-xdist/pull/35/commits (No official documentation available)
def pytest_xdist_node_collection_finished(node, ids):
    tests_collected.update(set(ids))


# link to pytest_collection_modifyitems
# https://docs.pytest.org/en/5.3.2/writing_plugins.html#hook-function-validation-and-execution
@pytest.hookimpl(tryfirst=True)
def pytest_collection_modifyitems(items):
    for item in items:
        tests_collected.add(item.nodeid)


# link to pytest_runtest_logreport
# https://docs.pytest.org/en/5.3.2/reference.html#_pytest.hookspec.pytest_runtest_logreport
def pytest_runtest_logreport(report):
    if report.passed:
        tests_executed.add(report.nodeid)


def pytest_addoption(parser):
    for config in all_configs:
        parser.addoption(config,
                         dest=all_configs[config][0],
                         default=all_configs[config][1],
                         help=all_configs[config][2])

    parser.addoption("--build_dir",
                     dest="build_dir",
                     default=f"{CURR_PATH}/../build",
                     help="Nebula Graph CMake build directory")


def pytest_configure(config):
    pytest.cmdline.address = config.getoption("address")
    pytest.cmdline.user = config.getoption("user")
    pytest.cmdline.password = config.getoption("password")
    pytest.cmdline.replica_factor = config.getoption("replica_factor")
    pytest.cmdline.partition_num = config.getoption("partition_num")
    if data_dir is None:
        pytest.cmdline.data_dir = config.getoption("data_dir")
    else:
        pytest.cmdline.data_dir = data_dir
    pytest.cmdline.stop_nebula = config.getoption("stop_nebula")
    pytest.cmdline.rm_dir = config.getoption("rm_dir")
    pytest.cmdline.debug_log = config.getoption("debug_log")


def get_conn_pool(host: str, port: int):
    config = Config()
    config.max_connection_pool_size = 20
    config.timeout = 120000
    # init connection pool
    pool = ConnectionPool()
    if not pool.init([(host, port)], config):
        raise Exception("Fail to init connection pool.")
    return pool


@pytest.fixture(scope="session")
def conn_pool(pytestconfig, worker_id, tmp_path_factory):
    addr = pytestconfig.getoption("address")
    if addr:
        addrsplit = addr.split(":")
        assert len(addrsplit) == 2
        pool = get_conn_pool(addrsplit[0], addrsplit[1])
        yield pool
        pool.close()
        return

    build_dir = pytestconfig.getoption("build_dir")
    rm_dir = pytestconfig.getoption("rm_dir")
    project_dir = os.path.dirname(CURR_PATH)

    root_tmp_dir = tmp_path_factory.getbasetemp().parent
    fn = root_tmp_dir / "nebula-test"
    nb = None
    with FileLock(str(fn) + ".lock"):
        if fn.is_file():
            data = json.loads(fn.read_text())
            port = data["port"]
            logging.info(f"session-{worker_id} read the port: {port}")
            pool = get_conn_pool("localhost", port)
            data["num_workers"] += 1
            fn.write_text(json.dumps(data))
        else:
            nb = NebulaService(build_dir, project_dir,
                               rm_dir.lower() == "true")
            nb.install()
            port = nb.start()
            pool = get_conn_pool("localhost", port)
            data = dict(port=port, num_workers=1, finished=0)
            fn.write_text(json.dumps(data))
            logging.info(f"session-{worker_id} write the port: {port}")

    yield pool
    pool.close()

    if nb is None:
        with FileLock(str(fn) + ".lock"):
            data = json.loads(fn.read_text())
            data["finished"] += 1
            fn.write_text(json.dumps(data))
    else:
        # TODO(yee): improve this option format, only specify it by `--stop_nebula`
        stop_nebula = pytestconfig.getoption("stop_nebula")
        while stop_nebula.lower() == "true":
            data = json.loads(fn.read_text())
            if data["finished"] + 1 == data["num_workers"]:
                nb.stop()
                break
            time.sleep(1)
        os.remove(str(fn))


@pytest.fixture(scope="class")
def session(conn_pool, pytestconfig):
    user = pytestconfig.getoption("user")
    password = pytestconfig.getoption("password")
    sess = conn_pool.get_session(user, password)
    yield sess
    sess.release()


def load_csv_data_once(
    tmp_path_factory,
    pytestconfig,
    worker_id,
    conn_pool: ConnectionPool,
    space: str,
):
    root_tmp_dir = tmp_path_factory.getbasetemp().parent
    fn = root_tmp_dir / f"csv-data-{space}"
    is_file = True
    with FileLock(str(fn) + ".lock"):
        if not fn.is_file():
            data_dir = os.path.join(CURR_PATH, "data", space)
            user = pytestconfig.getoption("user")
            password = pytestconfig.getoption("password")
            sess = conn_pool.get_session(user, password)
            space_desc = load_csv_data(pytestconfig, sess, data_dir)
            sess.release()
            fn.write_text(json.dumps(space_desc.__dict__))
            is_file = False
        else:
            space_desc = SpaceDesc.from_json(json.loads(fn.read_text()))
    if is_file:
        logging.info(f"session-{worker_id} need not to load {space} csv data")
        yield space_desc
    else:
        logging.info(f"session-{worker_id} load {space} csv data")
        yield space_desc
        os.remove(str(fn))


@pytest.fixture(scope="session")
def load_nba_data(conn_pool, pytestconfig, tmp_path_factory, worker_id):
    yield from load_csv_data_once(
        tmp_path_factory,
        pytestconfig,
        worker_id,
        conn_pool,
        "nba",
    )


@pytest.fixture(scope="session")
def load_nba_int_vid_data(
    conn_pool,
    pytestconfig,
    tmp_path_factory,
    worker_id,
):
    yield from load_csv_data_once(
        tmp_path_factory,
        pytestconfig,
        worker_id,
        conn_pool,
        "nba_int_vid",
    )


@pytest.fixture(scope="session")
def load_student_data(conn_pool, pytestconfig, tmp_path_factory, worker_id):
    yield from load_csv_data_once(
        tmp_path_factory,
        pytestconfig,
        worker_id,
        conn_pool,
        "student",
    )


# TODO(yee): Delete this when we migrate all test cases
@pytest.fixture(scope="class")
def workarround_for_class(request, pytestconfig, tmp_path_factory, conn_pool,
                          session, load_nba_data, load_student_data):
    if request.cls is None:
        return

    addr = pytestconfig.getoption("address")
    if addr:
        ss = addr.split(':')
        request.cls.host = ss[0]
        request.cls.port = ss[1]
    else:
        root_tmp_dir = tmp_path_factory.getbasetemp().parent
        fn = root_tmp_dir / "nebula-test"
        data = json.loads(fn.read_text())
        request.cls.host = "localhost"
        request.cls.port = data["port"]

    request.cls.data_dir = os.path.dirname(os.path.abspath(__file__))

    request.cls.spaces = []
    request.cls.user = pytestconfig.getoption("user")
    request.cls.password = pytestconfig.getoption("password")
    request.cls.replica_factor = pytestconfig.getoption("replica_factor")
    request.cls.partition_num = pytestconfig.getoption("partition_num")
    request.cls.check_format_str = 'result: {}, expect: {}'
    request.cls.data_loaded = False
    request.cls.client_pool = conn_pool
    request.cls.client = session
    request.cls.set_delay()
    request.cls.prepare()

    yield

    if request.cls.client is not None:
        request.cls.cleanup()
        request.cls.drop_data()
